import React from "react";
import { ProfileComponent } from "../../components/ProfileComponent/ProfileComponent";

export const Profile = () => {
  return (
    <div className="wrp">
      <ProfileComponent />
    </div>
  );
};
