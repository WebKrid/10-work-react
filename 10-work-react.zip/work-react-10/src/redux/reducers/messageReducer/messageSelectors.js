// селектор получения сообщений из редюсера
export const getMessageList = (state) => {
  return state.messageList.messageList;
};
