import {
  GET_POSTS,
  LOADING_POSTS,
  ERROR_POSTS,
} from "../../actions/actionTypes";
import { get_posts, error_posts, load_posts } from "../../actions/actions";


const initialState = {
  posts: [],
  loading: false,
  error: null,
};





export const postReducer = (state = initialState, action) => {
  switch (action.type) {
    case LOADING_POSTS:
      return {
        ...state,
        loading: true,
      };

    case GET_POSTS:
      return {
        ...state,
        posts: action.payload,
        loading: false,
      };

    case ERROR_POSTS:
      return {
        ...state,
        error: action.payload,
        loading: false,
      };

    default:
      return state;
  }
};


@load_posts - пока посты не загрузились
@get_posts - Получает посты
@error_posts - в случае ошибки

export const loadPosts = () => {
  return async (dispatch) => {
    dispatch(load_posts());
    try {
      const res = await fetch("https://jsonplaceholder.typicode.com/posts");
      const data = await res.json();
      dispatch(get_posts(data));
    } catch (err) {
      dispatch(error_posts(err));
    }
  };
};
